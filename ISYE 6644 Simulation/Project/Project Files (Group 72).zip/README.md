# Project Files

This folder contains the following files:

## Files

### 📓 Python Notebook (`Project Notebook (Group 72).ipynb`)
The primary file for this project. Contains all the code used to generate the charts and statistics referenced in the report. To reproduce the outputs, run each cell sequentially and selected cells will produce the figures and summary statistics included in the report.

### 🐍 Python Script (`Project Python Script (Group 72).py`)
A direct conversion of the notebook above. The code and outputs are identical. This file is provided as an alternative for reviewers who prefer to evaluate a plain Python script over a notebook format.

---

> **Note:** Both files are equivalent in content.
